---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2014-12-29T13:53:39
year: 2014
month: 12
day: 29
# Location terms
locationRemarks: Busselton Jetty,  Busselton /  Australia
minimumDepthInMeters: 6.62
maximumDepthInMeters: 6.64
decimalLatitude: -33.630113
decimalLatitude: 115.338566
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Mexichromis macropus
identificationQualifier: 
taxonRank: genus
---
