---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-01-10T09:03:09
year: 2016
month: 1
day: 10
# Location terms
locationRemarks: Point Peron, Rockingham / Australia
minimumDepthInMeters: 4.4
maximumDepthInMeters: 4.4
decimalLatitude: -32.270474
decimalLatitude: 115.684912
temperature: 25
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Chromodoris westraliensis
identificationQualifier: 
taxonRank: genus
---
