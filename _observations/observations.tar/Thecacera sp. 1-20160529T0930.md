---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-05-29T09:30:23
year: 2016
month: 5
day: 29
# Location terms
locationRemarks: Bicton Baths, Bicton / Australia
minimumDepthInMeters: 6.52
maximumDepthInMeters: 6.48
decimalLatitude: -32.027626
decimalLatitude: 115.777550
temperature: 18
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Thecacera
identificationQualifier: sp. 1
taxonRank: genus
---
