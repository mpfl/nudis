---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2019-01-12T09:15:13
year: 2019
month: 1
day: 12
# Location terms
locationRemarks: Ammunition Jetty,  Woodman Point /  Australia
minimumDepthInMeters: 6.13
maximumDepthInMeters: 6.19
decimalLatitude: -32.123948
decimalLatitude: 115.758068
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Flabellina
identificationQualifier: sp. 1
taxonRank: genus
---
