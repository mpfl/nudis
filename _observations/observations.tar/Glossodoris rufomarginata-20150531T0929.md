---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-05-31T09:29:10
year: 2015
month: 5
day: 31
# Location terms
locationRemarks: Marmion Angling And Aquatic Club,  Perth /  Australia
minimumDepthInMeters: 4.76
maximumDepthInMeters: 4.92
decimalLatitude: -31.839000
decimalLatitude: 115.749000
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Glossodoris rufomarginata
identificationQualifier: 
taxonRank: genus
---
