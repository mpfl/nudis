---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-01-02T10:12:37
year: 2015
month: 1
day: 2
# Location terms
locationRemarks: Ammunition Jetty,  Woodman Point /  Australia
minimumDepthInMeters: 2.48
maximumDepthInMeters: 2.36
decimalLatitude: -32.123948
decimalLatitude: 115.758068
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Hypselodoris
identificationQualifier: sp. 1
taxonRank: genus
---
