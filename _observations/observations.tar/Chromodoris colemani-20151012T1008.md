---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-10-12T10:08:17
year: 2015
month: 10
day: 12
# Location terms
locationRemarks: Woodman Point,  Woodman Point /  Australia
minimumDepthInMeters: 2.08
maximumDepthInMeters: 2.02
decimalLatitude: -32.138394
decimalLatitude: 115.743548
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Chromodoris colemani
identificationQualifier: 
taxonRank: genus
---
