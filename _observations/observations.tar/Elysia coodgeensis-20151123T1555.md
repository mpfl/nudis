---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-11-23T15:55:04
year: 2015
month: 11
day: 23
# Location terms
locationRemarks: Bicton Baths,  Bicton /  Australia
minimumDepthInMeters: 5.66
maximumDepthInMeters: 5.64
decimalLatitude: -32.028239
decimalLatitude: 115.776945
temperature: 25
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Elysia coodgeensis
identificationQualifier: 
taxonRank: genus
---
