---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-10-27T20:05:37
year: 2015
month: 10
day: 27
# Location terms
locationRemarks: Ammunition Jetty,  Woodman Point /  Australia
minimumDepthInMeters: 2.4
maximumDepthInMeters: 2.68
decimalLatitude: -32.123948
decimalLatitude: 115.758068
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Rostanga calumus
identificationQualifier: 
taxonRank: genus
---
