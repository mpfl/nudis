---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: OLYMPUS DIGITAL CAMERA
# Event terms
eventDateTime: 2021-04-05T09:39:45
year: 2021
month: 4
day: 5
# Location terms
locationRemarks: Sue's Groyne /  Australia
minimumDepthInMeters: 6.2
maximumDepthInMeters: 5.9
decimalLatitude: -32.096888
decimalLatitude: 115.757000
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Goniobranchus aureopurpureus
identificationQualifier: 
taxonRank: genus
---
