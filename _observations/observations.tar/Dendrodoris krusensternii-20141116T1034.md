---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2014-11-16T10:34:13
year: 2014
month: 11
day: 16
# Location terms
locationRemarks: Bhp Jetty,  Kwinana /  Australia
minimumDepthInMeters: 5.06
maximumDepthInMeters: 5.28
decimalLatitude: -32.208888
decimalLatitude: 115.766000
temperature: 30
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Dendrodoris krusensternii
identificationQualifier: 
taxonRank: genus
---
