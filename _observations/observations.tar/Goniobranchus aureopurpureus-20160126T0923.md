---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-01-26T09:23:28
year: 2016
month: 1
day: 26
# Location terms
locationRemarks: Rockingham Dive Trail, Rockingham, Australia
minimumDepthInMeters: 9.56
maximumDepthInMeters: 9.6
decimalLatitude: -32.273019
decimalLatitude: 115.730226
temperature: 30
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Goniobranchus aureopurpureus
identificationQualifier: 
taxonRank: genus
---
