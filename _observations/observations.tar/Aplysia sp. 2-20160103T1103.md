---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-01-03T11:03:26
year: 2016
month: 1
day: 3
# Location terms
locationRemarks: Point Peron, Rockingham / Australia
minimumDepthInMeters: 2.4
maximumDepthInMeters: 2.7
decimalLatitude: -32.270474
decimalLatitude: 115.684912
temperature: 25
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Aplysia
identificationQualifier: sp. 2
taxonRank: genus
---
