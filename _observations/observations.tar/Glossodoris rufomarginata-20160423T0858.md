---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-04-23T08:58:35
year: 2016
month: 4
day: 23
# Location terms
locationRemarks: Woodman Point Groin, Coogee
minimumDepthInMeters: 6.82
maximumDepthInMeters: 6.76
decimalLatitude: -32.137831
decimalLatitude: 115.744733
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Glossodoris rufomarginata
identificationQualifier: 
taxonRank: genus
---
