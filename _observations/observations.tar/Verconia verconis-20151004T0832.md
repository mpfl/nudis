---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-10-04T08:32:40
year: 2015
month: 10
day: 4
# Location terms
locationRemarks: Ammunition Jetty,  Woodman Point /  Australia
minimumDepthInMeters: 6.88
maximumDepthInMeters: 6.88
decimalLatitude: -32.123948
decimalLatitude: 115.758068
temperature: 19
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Verconia verconis
identificationQualifier: 
taxonRank: genus
---
