---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-11-28T11:43:48
year: 2015
month: 11
day: 28
# Location terms
locationRemarks: Underwater Interpretive Snorkel And Dive Trail,  Jurien Bay /  Australia
minimumDepthInMeters: 4.72
maximumDepthInMeters: 4.94
decimalLatitude: -30.300726
decimalLatitude: 115.037155
temperature: 25
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Dendrodoris krusensternii
identificationQualifier: 
taxonRank: genus
---
