---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-12-20T08:13:32
year: 2015
month: 12
day: 20
# Location terms
locationRemarks: South Mole,  Fremantle /  Australia
minimumDepthInMeters: 2.78
maximumDepthInMeters: 3.0
decimalLatitude: -32.056888
decimalLatitude: 115.740000
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Gymnodoris alba
identificationQualifier: 
taxonRank: genus
---
