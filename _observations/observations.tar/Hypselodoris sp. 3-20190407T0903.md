---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2019-04-07T09:03:40
year: 2019
month: 4
day: 7
# Location terms
locationRemarks: Woodman Point,  Woodman Point /  Australia
minimumDepthInMeters: 9.0
maximumDepthInMeters: 8.5
decimalLatitude: -32.138394
decimalLatitude: 115.743548
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Hypselodoris
identificationQualifier: sp. 3
taxonRank: genus
---
