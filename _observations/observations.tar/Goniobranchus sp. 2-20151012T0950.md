---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-10-12T09:50:56
year: 2015
month: 10
day: 12
# Location terms
locationRemarks: Woodman Point,  Woodman Point /  Australia
minimumDepthInMeters: 2.58
maximumDepthInMeters: 2.56
decimalLatitude: -32.138394
decimalLatitude: 115.743548
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Goniobranchus
identificationQualifier: sp. 2
taxonRank: genus
---
