---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2019-05-12T10:28:59
year: 2019
month: 5
day: 12
# Location terms
locationRemarks: South Mole, Fremantle, Australia
minimumDepthInMeters: 2.9
maximumDepthInMeters: 2.9
decimalLatitude: -32.057053
decimalLatitude: 115.738735
temperature: 19
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Elysia
identificationQualifier: sp. 2
taxonRank: genus
---
