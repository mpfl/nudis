---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-03-22T09:58:13
year: 2015
month: 3
day: 22
# Location terms
locationRemarks: Ammunition Jetty,  Woodman Point /  Australia
minimumDepthInMeters: 4.04
maximumDepthInMeters: 3.92
decimalLatitude: -32.123948
decimalLatitude: 115.758068
temperature: 22
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Hypselodoris
identificationQualifier: sp. 1
taxonRank: genus
---
