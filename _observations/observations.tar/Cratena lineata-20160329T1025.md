---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-03-29T10:25:38
year: 2016
month: 3
day: 29
# Location terms
locationRemarks: Ammunition Jetty, Coogee, Australia
minimumDepthInMeters: 6.48
maximumDepthInMeters: 7.22
decimalLatitude: -32.124000
decimalLatitude: 115.758000
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Cratena lineata
identificationQualifier: 
taxonRank: genus
---
