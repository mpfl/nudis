---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: OLYMPUS DIGITAL CAMERA
# Event terms
eventDateTime: 2021-05-07T11:28:55
year: 2021
month: 5
day: 7
# Location terms
locationRemarks: Busselton Jetty,  Busselton /  Australia
minimumDepthInMeters: 7.7
maximumDepthInMeters: 8.0
decimalLatitude: -33.630113
decimalLatitude: 115.338566
temperature: 20
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Pteraeolidia semperi
identificationQualifier: 
taxonRank: genus
---
