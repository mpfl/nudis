---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2014-12-27T10:14:50
year: 2014
month: 12
day: 27
# Location terms
locationRemarks: Lena,  Bunbury /  Australia
minimumDepthInMeters: 16.7
maximumDepthInMeters: 17.08
decimalLatitude: -33.296111
decimalLatitude: 115.609000
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Chromodoris westraliensis
identificationQualifier: 
taxonRank: genus
---
