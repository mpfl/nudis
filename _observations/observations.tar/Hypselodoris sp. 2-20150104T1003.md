---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-01-04T10:03:22
year: 2015
month: 1
day: 4
# Location terms
locationRemarks: Ammunition Jetty,  Woodman Point /  Australia
minimumDepthInMeters: 7.92
maximumDepthInMeters: 7.9
decimalLatitude: -32.123948
decimalLatitude: 115.758068
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Hypselodoris
identificationQualifier: sp. 2
taxonRank: genus
---
