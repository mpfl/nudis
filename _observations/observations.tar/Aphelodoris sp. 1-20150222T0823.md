---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-02-22T08:23:06
year: 2015
month: 2
day: 22
# Location terms
locationRemarks: Rockingham Dive Trail, Rockingham, Australia
minimumDepthInMeters: 17.18
maximumDepthInMeters: 17.3
decimalLatitude: -32.273019
decimalLatitude: 115.730226
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Aphelodoris
identificationQualifier: sp. 1
taxonRank: genus
---
