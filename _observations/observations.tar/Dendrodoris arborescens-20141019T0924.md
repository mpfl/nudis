---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2014-10-19T09:24:57
year: 2014
month: 10
day: 19
# Location terms
locationRemarks: Grain Terminal,  Kwinana /  Australia
minimumDepthInMeters: 4.22
maximumDepthInMeters: 4.12
decimalLatitude: -32.256193
decimalLatitude: 115.748000
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Dendrodoris arborescens
identificationQualifier: 
taxonRank: genus
---
