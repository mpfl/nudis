---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-04-15T12:39:42
year: 2015
month: 4
day: 15
# Location terms
locationRemarks: Busselton Jetty,  Busselton /  Australia
minimumDepthInMeters: 6.88
maximumDepthInMeters: 6.2
decimalLatitude: -33.630113
decimalLatitude: 115.338566
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Trapania safracornia
identificationQualifier: 
taxonRank: genus
---
