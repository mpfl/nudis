---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-11-19T09:06:07
year: 2016
month: 11
day: 19
# Location terms
locationRemarks: South Mole,  Fremantle /  Australia
minimumDepthInMeters: 1.82
maximumDepthInMeters: 1.74
decimalLatitude: -32.056888
decimalLatitude: 115.740000
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Dendrodoris
identificationQualifier: sp. 1
taxonRank: genus
---
