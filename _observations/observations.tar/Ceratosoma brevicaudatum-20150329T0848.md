---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-03-29T08:48:22
year: 2015
month: 3
day: 29
# Location terms
locationRemarks: Ammunition Jetty,  Woodman Point /  Australia
minimumDepthInMeters: 2.38
maximumDepthInMeters: 2.54
decimalLatitude: -32.123948
decimalLatitude: 115.758068
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Ceratosoma brevicaudatum
identificationQualifier: 
taxonRank: genus
---
