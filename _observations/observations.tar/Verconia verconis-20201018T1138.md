---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: OLYMPUS DIGITAL CAMERA
# Event terms
eventDateTime: 2020-10-18T11:38:21
year: 2020
month: 10
day: 18
# Location terms
locationRemarks: Busselton Jetty,  Busselton /  Australia
minimumDepthInMeters: 7.6
maximumDepthInMeters: 7.1
decimalLatitude: -33.630113
decimalLatitude: 115.338566
temperature: 18
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Verconia verconis
identificationQualifier: 
taxonRank: genus
---
