---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-03-08T09:51:13
year: 2015
month: 3
day: 8
# Location terms
locationRemarks: Sue's Groyne /  Australia
minimumDepthInMeters: 6.02
maximumDepthInMeters: 6.08
decimalLatitude: -32.096888
decimalLatitude: 115.757000
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Chromodoris colemani
identificationQualifier: 
taxonRank: genus
---
