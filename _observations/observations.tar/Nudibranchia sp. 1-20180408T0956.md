---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2018-04-08T09:56:57
year: 2018
month: 4
day: 8
# Location terms
locationRemarks: Woodman Point,  Woodman Point /  Australia
minimumDepthInMeters: 6.73
maximumDepthInMeters: 6.87
decimalLatitude: -32.138394
decimalLatitude: 115.743548
temperature: 22
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Nudibranchia
identificationQualifier: sp. 1
taxonRank: genus
---
