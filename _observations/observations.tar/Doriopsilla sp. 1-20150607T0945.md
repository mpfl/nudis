---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-06-07T09:45:18
year: 2015
month: 6
day: 7
# Location terms
locationRemarks: Grain Terminal,  Kwinana /  Australia
minimumDepthInMeters: 4.4
maximumDepthInMeters: 4.58
decimalLatitude: -32.256193
decimalLatitude: 115.748000
temperature: 25
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Doriopsilla
identificationQualifier: sp. 1
taxonRank: genus
---
