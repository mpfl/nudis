---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-09-20T10:39:54
year: 2015
month: 9
day: 20
# Location terms
locationRemarks: Grain Terminal,  Kwinana /  Australia
minimumDepthInMeters: 4.06
maximumDepthInMeters: 4.12
decimalLatitude: -32.256193
decimalLatitude: 115.748000
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Mexichromis mariei
identificationQualifier: 
taxonRank: genus
---
