---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-03-06T08:45:57
year: 2016
month: 3
day: 6
# Location terms
locationRemarks: South Mole, Fremantle, Australia
minimumDepthInMeters: 2.06
maximumDepthInMeters: 2.02
decimalLatitude: -32.057053
decimalLatitude: 115.738735
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Elysia
identificationQualifier: sp. 1
taxonRank: genus
---
