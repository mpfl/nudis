---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-12-20T08:02:10
year: 2015
month: 12
day: 20
# Location terms
locationRemarks: South Mole,  Fremantle /  Australia
minimumDepthInMeters: 1.7
maximumDepthInMeters: 2.02
decimalLatitude: -32.056888
decimalLatitude: 115.740000
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Madrella ferruginosa
identificationQualifier: 
taxonRank: genus
---
