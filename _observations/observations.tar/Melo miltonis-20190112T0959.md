---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2019-01-12T09:59:51
year: 2019
month: 1
day: 12
# Location terms
locationRemarks: Ammunition Jetty,  Woodman Point /  Australia
minimumDepthInMeters: 4.86
maximumDepthInMeters: 4.8
decimalLatitude: -32.123948
decimalLatitude: 115.758068
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Melo miltonis
identificationQualifier: 
taxonRank: genus
---
