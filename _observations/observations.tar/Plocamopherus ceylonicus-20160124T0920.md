---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-01-24T09:20:16
year: 2016
month: 1
day: 24
# Location terms
locationRemarks: Grain Terminal,  Kwinana /  Australia
minimumDepthInMeters: 3.58
maximumDepthInMeters: 3.37
decimalLatitude: -32.256193
decimalLatitude: 115.748000
temperature: 25
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Plocamopherus ceylonicus
identificationQualifier: 
taxonRank: genus
---
