---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-04-23T09:55:38
year: 2016
month: 4
day: 23
# Location terms
locationRemarks: Woodman Point Groin, Coogee
minimumDepthInMeters: 5.05
maximumDepthInMeters: 6.27
decimalLatitude: -32.137831
decimalLatitude: 115.744733
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Hypselodoris
identificationQualifier: sp. 2
taxonRank: genus
---
