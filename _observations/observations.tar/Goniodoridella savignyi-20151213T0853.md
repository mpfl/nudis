---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-12-13T08:53:49
year: 2015
month: 12
day: 13
# Location terms
locationRemarks: Ammunition Jetty,  Woodman Point /  Australia
minimumDepthInMeters: 5.22
maximumDepthInMeters: 5.2
decimalLatitude: -32.123948
decimalLatitude: 115.758068
temperature: 22
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Goniodoridella savignyi
identificationQualifier: 
taxonRank: genus
---
