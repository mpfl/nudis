---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-03-08T10:13:19
year: 2015
month: 3
day: 8
# Location terms
locationRemarks: Sue's Groyne /  Australia
minimumDepthInMeters: 4.3
maximumDepthInMeters: 4.72
decimalLatitude: -32.096888
decimalLatitude: 115.757000
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Hypselodoris saintvincentia
identificationQualifier: 
taxonRank: genus
---
