---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-02-08T13:19:28
year: 2015
month: 2
day: 8
# Location terms
locationRemarks: Low Caves,  Rottnest /  Australia
minimumDepthInMeters: 10.74
maximumDepthInMeters: 11.5
decimalLatitude: -32.005694
decimalLatitude: 115.461000
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Chromodoris westraliensis
identificationQualifier: 
taxonRank: genus
---
