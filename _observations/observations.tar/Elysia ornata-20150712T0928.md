---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-07-12T09:28:19
year: 2015
month: 7
day: 12
# Location terms
locationRemarks: Bhp Jetty,  Kwinana /  Australia
minimumDepthInMeters: 6.52
maximumDepthInMeters: 6.1
decimalLatitude: -32.208888
decimalLatitude: 115.766000
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Elysia ornata
identificationQualifier: 
taxonRank: genus
---
