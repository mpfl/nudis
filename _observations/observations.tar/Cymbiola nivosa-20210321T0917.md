---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: OLYMPUS DIGITAL CAMERA
# Event terms
eventDateTime: 2021-03-21T09:17:17
year: 2021
month: 3
day: 21
# Location terms
locationRemarks: Gareenup Wreck, North Fremantle / Australia
minimumDepthInMeters: 7.6
maximumDepthInMeters: 7.6
decimalLatitude: -32.052437
decimalLatitude: 115.725339
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Cymbiola nivosa
identificationQualifier: 
taxonRank: genus
---
