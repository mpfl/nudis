---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2014-11-16T11:12:37
year: 2014
month: 11
day: 16
# Location terms
locationRemarks: Bhp Jetty,  Kwinana /  Australia
minimumDepthInMeters: 7.76
maximumDepthInMeters: 7.48
decimalLatitude: -32.208888
decimalLatitude: 115.766000
temperature: 22
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Aphelodoris
identificationQualifier: sp. 1
taxonRank: genus
---
