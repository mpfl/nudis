---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-03-08T10:05:51
year: 2015
month: 3
day: 8
# Location terms
locationRemarks: Sue's Groyne /  Australia
minimumDepthInMeters: 4.22
maximumDepthInMeters: 4.38
decimalLatitude: -32.096888
decimalLatitude: 115.757000
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Thordisa
identificationQualifier: sp. 1
taxonRank: genus
---
