---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-03-02T08:29:45
year: 2015
month: 3
day: 2
# Location terms
locationRemarks: Grain Terminal,  Kwinana /  Australia
minimumDepthInMeters: 1.56
maximumDepthInMeters: 1.62
decimalLatitude: -32.256193
decimalLatitude: 115.748000
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Mexichromis macropus
identificationQualifier: 
taxonRank: genus
---
