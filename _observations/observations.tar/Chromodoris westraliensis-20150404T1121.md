---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-04-04T11:21:20
year: 2015
month: 4
day: 4
# Location terms
locationRemarks: The Caves,  Mindarie /  Australia
minimumDepthInMeters: 10.46
maximumDepthInMeters: 10.36
decimalLatitude: -31.688305
decimalLatitude: 115.648000
temperature: 25
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Chromodoris westraliensis
identificationQualifier: 
taxonRank: genus
---
