---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-01-30T11:16:33
year: 2016
month: 1
day: 30
# Location terms
locationRemarks: Busselton Jetty,  Busselton /  Australia
minimumDepthInMeters: 7.37
maximumDepthInMeters: 7.37
decimalLatitude: -33.630113
decimalLatitude: 115.338566
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Ceratosoma brevicaudatum
identificationQualifier: 
taxonRank: genus
---
