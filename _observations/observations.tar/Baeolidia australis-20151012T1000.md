---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-10-12T10:00:54
year: 2015
month: 10
day: 12
# Location terms
locationRemarks: Woodman Point,  Woodman Point /  Australia
minimumDepthInMeters: 3.56
maximumDepthInMeters: 3.44
decimalLatitude: -32.138394
decimalLatitude: 115.743548
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Baeolidia australis
identificationQualifier: 
taxonRank: genus
---
