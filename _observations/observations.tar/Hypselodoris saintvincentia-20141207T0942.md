---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2014-12-07T09:42:09
year: 2014
month: 12
day: 7
# Location terms
locationRemarks: Robb's Jetty /  Australia
minimumDepthInMeters: 5.08
maximumDepthInMeters: 5.34
decimalLatitude: -32.089388
decimalLatitude: 115.754000
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Hypselodoris saintvincentia
identificationQualifier: 
taxonRank: genus
---
