---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-01-26T09:54:55
year: 2016
month: 1
day: 26
# Location terms
locationRemarks: Rockingham Dive Trail, Rockingham, Australia
minimumDepthInMeters: 15.37
maximumDepthInMeters: 15.74
decimalLatitude: -32.273019
decimalLatitude: 115.730226
temperature: 25
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Polycera hedgpethi
identificationQualifier: 
taxonRank: genus
---
