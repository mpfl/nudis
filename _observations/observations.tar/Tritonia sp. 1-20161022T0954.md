---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2016-10-22T09:54:36
year: 2016
month: 10
day: 22
# Location terms
locationRemarks: Ammunition Jetty, Coogee, Australia
minimumDepthInMeters: 6.76
maximumDepthInMeters: 7.37
decimalLatitude: -32.124000
decimalLatitude: 115.758000
temperature: 18
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Tritonia
identificationQualifier: sp. 1
taxonRank: genus
---
