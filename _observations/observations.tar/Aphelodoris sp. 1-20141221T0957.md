---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2014-12-21T09:57:12
year: 2014
month: 12
day: 21
# Location terms
locationRemarks: Bhp Jetty,  Kwinana /  Australia
minimumDepthInMeters: 8.18
maximumDepthInMeters: 8.38
decimalLatitude: -32.208888
decimalLatitude: 115.766000
temperature: 23
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Aphelodoris
identificationQualifier: sp. 1
taxonRank: genus
---
