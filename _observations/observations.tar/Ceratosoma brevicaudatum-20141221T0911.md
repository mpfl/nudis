---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2014-12-21T09:11:55
year: 2014
month: 12
day: 21
# Location terms
locationRemarks: Bhp Jetty,  Kwinana /  Australia
minimumDepthInMeters: 4.26
maximumDepthInMeters: 4.22
decimalLatitude: -32.208888
decimalLatitude: 115.766000
temperature: 24
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Ceratosoma brevicaudatum
identificationQualifier: 
taxonRank: genus
---
