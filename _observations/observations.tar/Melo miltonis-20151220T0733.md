---
# Record-level terms
type: StillImage
basisOfRecord: HumanObservation
# Occurrence terms
recordedBy: Matthias Liffers
recordedByID: https://orcid.org/0000-0002-3639-2080
occurrenceRemarks: 
# Event terms
eventDateTime: 2015-12-20T07:33:55
year: 2015
month: 12
day: 20
# Location terms
locationRemarks: South Mole,  Fremantle /  Australia
minimumDepthInMeters: 1.54
maximumDepthInMeters: 1.54
decimalLatitude: -32.056888
decimalLatitude: 115.740000
temperature: 21
# Identification terms
identifiedBy: 
identifiedByID: 
# Taxon terms
scientificName: Melo miltonis
identificationQualifier: 
taxonRank: genus
---
